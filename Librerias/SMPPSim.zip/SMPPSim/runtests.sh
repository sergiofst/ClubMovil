CLASSPATH=smppsim.jar:lib/junit.jar:classes:lib/smpp.jar
java -classpath $CLASSPATH tests/SmppsimTests
