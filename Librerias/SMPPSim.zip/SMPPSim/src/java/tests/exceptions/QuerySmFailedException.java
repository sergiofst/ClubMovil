/*
 * Copyright (c) 2004
 * Martin Woolley
 * All rights reserved.
 *
 */
package tests.exceptions;

public class QuerySmFailedException extends Exception {
	public QuerySmFailedException() {
		super();
	}

}
