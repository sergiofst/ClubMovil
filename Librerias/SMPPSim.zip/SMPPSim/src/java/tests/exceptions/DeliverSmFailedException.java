/*
 * Copyright (c) 2004
 * Martin Woolley
 * All rights reserved.
 *
 */
package tests.exceptions;

public class DeliverSmFailedException extends Exception {
	public DeliverSmFailedException() {
		super();
	}

}
